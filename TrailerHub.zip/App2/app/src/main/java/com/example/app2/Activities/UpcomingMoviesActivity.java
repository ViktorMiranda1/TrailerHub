package com.example.app2.Activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.app2.Adapters.FilmListAdapter;
import com.example.app2.Domains.Film;
import com.example.app2.R;
import com.example.app2.databinding.ActivityUpcomingMoviesBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UpcomingMoviesActivity extends AppCompatActivity {
    // Declaração de binding para acessar o layout e componentes de UI
    ActivityUpcomingMoviesBinding binding;
    // Declaração do banco de dados Firebase
    private FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inicializa o binding para acessar os componentes do layout
        binding = ActivityUpcomingMoviesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        // Inicializa a instância do banco de dados Firebase
        database = FirebaseDatabase.getInstance();
        // Chama o método para carregar os filmes futuros
        initUpcomingMovies();
        // Configura o botão de voltar para finalizar a atividade ao ser clicado
        binding.backImgUp.setOnClickListener(view -> finish());
    }
    // Método que busca e exibe os filmes futuros do Firebase
    private void initUpcomingMovies() {
        // Referência ao nó "Upcomming" no banco de dados Firebase
        DatabaseReference myRef = database.getReference("Upcomming");
        // Exibe a barra de progresso enquanto os dados são carregados
        binding.progressBarUp.setVisibility(View.VISIBLE);
        // Cria uma lista para armazenar os filmes recebidos
        ArrayList<Film> upcomming = new ArrayList<>();
        // Adiciona um ouvinte de evento para ler os dados uma vez
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Topico pedido pelo professor
                // Verifica se o nó "Upcomming" possui dados
                if (snapshot.exists()){
                    // Para cada filme no nó "Upcomming", converte para um objeto Film e adiciona à lista
                    for (DataSnapshot issue: snapshot.getChildren()){
                        upcomming.add(issue.getValue(Film.class));
                    }
                    // Se a lista de filmes não estiver vazia, configura o RecyclerView com os dados
                    if (!upcomming.isEmpty()){
                        // Define o layout do RecyclerView como lista vertical
                        binding.recyclerViewUp.setLayoutManager(new LinearLayoutManager(UpcomingMoviesActivity.this));
                        // Configura o adaptador do RecyclerView com a lista de filmes
                        binding.recyclerViewUp.setAdapter(new FilmListAdapter(upcomming));
                    }
                    // Esconde a barra de progresso após o carregamento
                    binding.progressBarUp.setVisibility(View.GONE);

                } else {
                    // Caso não existam dados no nó, exibe uma mensagem de log
                    Log.d("UpcomingMovies", "No data found");
                }// Esconde a barra de progresso mesmo se não houver dados
                binding.progressBarUp.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Em caso de erro na leitura dos dados, exibe a mensagem de erro no log
                Log.e("UpcomingMovies", "Error fetching data", error.toException());
                // Esconde a barra de progresso em caso de erro
                binding.progressBarUp.setVisibility(View.GONE);
            }
        });    }

}