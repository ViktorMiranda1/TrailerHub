package com.example.app2.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.app2.Domains.SliderItems;
import com.example.app2.R;

import java.util.List;

public class SlidersAdapter extends RecyclerView.Adapter<SlidersAdapter.SliderViewHolder> {
    private List<SliderItems> sliderItems;// Lista que armazena os itens para o slider
    private ViewPager2 viewPager2;// Lista que armazena os itens para o slider
    private Context context;// O contexto da aplicação
    private Runnable runnable=new Runnable() { // Runnable que duplica a lista de slides quando atinge o penúltimo item, criando um efeito de loop
        @Override
        public void run() {
            sliderItems.addAll(sliderItems); // Duplicar os itens no final da lista
            notifyDataSetChanged();// Notifica o adaptador para atualizar a exibição
        }
    };
    // Construtor que recebe o ViewPager2 e a lista de itens
    public SlidersAdapter(ViewPager2 viewPager2, List<SliderItems> sliderItems) {
        this.viewPager2 = viewPager2;
        this.sliderItems = sliderItems;
    }

    @NonNull
    @Override
    public SlidersAdapter.SliderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context=parent.getContext(); // Inicializa o contexto com o contexto do pai
        // Infla o layout do item do slider e retorna o ViewHolder correspondente
        return new SliderViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.slider_viewholder, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SlidersAdapter.SliderViewHolder holder, int position) {
        holder.setImage(sliderItems.get(position));// Define a imagem e os textos no ViewHolder com base na posição atual
        if(position == sliderItems.size()-2){// Quando atinge o penúltimo item
            viewPager2.post(runnable);// Executa o Runnable para duplicar os itens e criar o efeito de looping
        }
    }

    @Override
    public int getItemCount() {
        return sliderItems.size();
    }// Retorna o número de itens no slider
    // ViewHolder responsável por definir os elementos da interface para cada slide
    public class SliderViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView;// Exibe a imagem do slide
        private TextView nameTxt, genreTxt, ageTxt, yearTxt, timeTxt;// Exibe os detalhes do slide
        public SliderViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.imageSlide);// Inicializa a ImageView
            nameTxt = itemView.findViewById(R.id.nameTxt); // Nome do filme
            genreTxt = itemView.findViewById(R.id.genreTxt);// Gênero do filme
            ageTxt = itemView.findViewById(R.id.ageTxt);// Classificação etária
            yearTxt = itemView.findViewById(R.id.yearTxt);// Ano de lançamento
            timeTxt = itemView.findViewById(R.id.timeTxt);// Duração do filme
        }
        // Método que define os valores da imagem e dos textos para cada item do slider
        void setImage(SliderItems sliderItems){
            RequestOptions requestOptions=new RequestOptions();
            requestOptions = requestOptions.transform(new CenterCrop(), new RoundedCorners(60));// Aplica bordas arredondadas à imagem
            // Carrega a imagem usando Glide
            Glide.with(context)
                    .load(sliderItems.getImage())// Carrega a imagem do item
                    .apply(requestOptions) // Aplica as transformações (center crop e bordas arredondadas)
                    .into(imageView);// Define a imagem na ImageView
            // Define os textos dos detalhes do item
            nameTxt.setText(sliderItems.getName());// Define o nome
            genreTxt.setText(sliderItems.getGenre()); // Define o gênero
            ageTxt.setText(sliderItems.getAge()); // Define a classificação etária
            yearTxt.setText("" + sliderItems.getYear()); // Define a classificação etária
            timeTxt.setText(sliderItems.getTime()); // Define a duração
        }
    }
}
