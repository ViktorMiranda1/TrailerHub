package com.example.app2.Activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import com.example.app2.Adapters.FilmListAdapter;
import com.example.app2.Adapters.SlidersAdapter;
import com.example.app2.Domains.Film;
import com.example.app2.Domains.SliderItems;
import com.example.app2.R;
import com.example.app2.databinding.ActivityMainBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;// Usado para vincular os componentes da interface (View Binding)
    private FirebaseDatabase database;// Referência ao banco de dados Firebase
    private Handler sliderHandler = new Handler();// Handler para gerenciar as trocas automáticas de banners
    private ChipNavigationBar chipNavigationBar;
    private Runnable sliderRunnable = new Runnable() {// Runnable que avança para o próximo banner após um intervalo
        @Override
        public void run() {
            binding.viewPager2.setCurrentItem(binding.viewPager2.getCurrentItem()+1);
            
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());// Inicializa o View Binding
        setContentView(binding.getRoot());// Define o layout raiz

        database=FirebaseDatabase.getInstance();// Inicializa o Firebase

        // Remove os limites da janela para dar a sensação de "tela cheia"
        Window w=getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        Toolbar toolbar = findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(""); // tira o titulo


        initBanner();// Inicializa os banners
        initTopMoving();// Inicializa a lista de filmes populares
        initUpcoming(); // Inicializa a lista de filmes que serão lançados em breve
        initNolan();
        setupButtonListenners();
        // Tentativa de configurar a barra de navegação
//        chipNavigationBar = findViewById(R.id.bottom_nav);
//        setupNavigation();
        }//Quando selecionado para ver todas as opções, manda para a tela com o catálogo


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if (id == R.id.action_settings){
            Toast.makeText(this, "Settings clicked", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_about) {
            String url = "https://www.canva.com/design/DAGTyP3yibE/o-uMRea0Q3IMm-Cf7jJlwg/edit?utm_content=DAGTyP3yibE&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton"; // Substitua pelo seu link
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupButtonListenners(){
            binding.buttomTopMovies.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, TopMoviesActivity.class));
            });

            binding.buttonUpcomingMovies.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, UpcomingMoviesActivity.class));
            });
            binding.buttonNolanMovies.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, NolanMovies.class));
            });
        }
    private void initNolan() {
        Log.d("MainActivity", "Iniciando initNolan()");
        DatabaseReference myRef=database.getReference("Nolan Movies");// Referência ao nó "Nolan" no Firebase
        binding.progressBarNolan.setVisibility(View.VISIBLE); // Mostra a barra de progresso enquanto carrega os dados
        ArrayList<Film> items=new ArrayList<>(); // Lista de filmes
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){ // Verifica se há dados no nó
                    for (DataSnapshot issue:snapshot.getChildren()){
                        items.add(issue.getValue(Film.class));// Adiciona cada filme à lista
                    }
                    if(!items.isEmpty()){// Se a lista não estiver vazia, configura o RecyclerView
                        binding.recyclerViewNolan.setLayoutManager(new LinearLayoutManager(MainActivity.this,
                                LinearLayoutManager.HORIZONTAL, false));// Define o layout horizontal
                        binding.recyclerViewNolan.setAdapter(new FilmListAdapter(items));// Define o adaptador com os dados
                    }
                    binding.progressBarNolan.setVisibility(View.GONE);// Esconde a barra de progresso
                }
            }

            @Override //Caso haja erro, manda uma msg
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Erro ao buscar dados: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    // Método que carrega os filmes que serão lançados em breve
    private void initUpcoming(){
        DatabaseReference myRef=database.getReference("Upcomming");// Referência ao nó "Upcomming" no Firebase
        binding.progressBarUpcoming.setVisibility(View.VISIBLE); // Mostra a barra de progresso enquanto carrega os dados
        ArrayList<Film> items=new ArrayList<>(); // Lista de filmes
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){ // Verifica se há dados no nó
                    for (DataSnapshot issue:snapshot.getChildren()){
                        items.add(issue.getValue(Film.class));// Adiciona cada filme à lista
                    }
                    if(!items.isEmpty()){// Se a lista não estiver vazia, configura o RecyclerView
                        binding.recyclerViewUpcoming.setLayoutManager(new LinearLayoutManager(MainActivity.this,
                                LinearLayoutManager.HORIZONTAL, false));// Define o layout horizontal
                        binding.recyclerViewUpcoming.setAdapter(new FilmListAdapter(items));// Define o adaptador com os dados
                    }
                    binding.progressBarUpcoming.setVisibility(View.GONE);// Esconde a barra de progresso
                }
            }

            @Override //Caso haja erro, manda uma msg
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Erro ao buscar dados: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    // Método que carrega os filmes populares
    private void initTopMoving(){
        DatabaseReference myRef=database.getReference("Items");// Referência ao nó "Items" no Firebase
        binding.progressBarTop.setVisibility(View.VISIBLE); // Mostra a barra de progresso
        ArrayList<Film> items=new ArrayList<>();// Lista de filmes
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){ // Verifica se há dados
                    for (DataSnapshot issue:snapshot.getChildren()){
                        items.add(issue.getValue(Film.class));// Adiciona os filmes à lista
                    }
                    if(!items.isEmpty()){// Configura o RecyclerView se houver filmes
                        binding.recyclerViewTopMovies.setLayoutManager(new LinearLayoutManager(MainActivity.this,
                                LinearLayoutManager.HORIZONTAL, false));// Layout horizontal
                        binding.recyclerViewTopMovies.setAdapter(new FilmListAdapter(items)); // Define o adaptador
                    }
                    binding.progressBarTop.setVisibility(View.GONE);// Esconde a barra de progresso

                }
            }

            @Override// Lida com erros na leitura dos dados (não implementado)
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    } //Metodo que carrega os banners, basicamente a mesma coisa do top movies
    private void initBanner(){
        DatabaseReference myRef=database.getReference("Banners");
        binding.progressBarBanner.setVisibility(View.VISIBLE);
        ArrayList<SliderItems> items=new ArrayList<>();
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    for (DataSnapshot issue:snapshot.getChildren()){
                        items.add(issue.getValue(SliderItems.class));
                    }
                    banners(items);
                    binding.progressBarBanner.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }// Configura o comportamento do ViewPager para exibir os banners com efeitos de transição
    private void banners(ArrayList<SliderItems> items){
        binding.viewPager2.setAdapter(new SlidersAdapter(binding.viewPager2, items)); // Define o adaptador para os banners
        binding.viewPager2.setClipToPadding(false);
        binding.viewPager2.setClipChildren(false);
        binding.viewPager2.setOffscreenPageLimit(3); // Mantém 3 páginas em cache
        binding.viewPager2.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);// Desativa o overscroll
        // Configura o comportamento de transição das páginas (deslize entre banners)
        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
        compositePageTransformer.addTransformer(new MarginPageTransformer(40));// Define a margem entre as páginas
        compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r=1-Math.abs(position);// Reduz o tamanho das páginas ao deslizarem para fora da tela
                page.setScaleY(0.85f+r*0.15f);// Aplica o efeito de escala (zoom)
            }
        });
        binding.viewPager2.setPageTransformer(compositePageTransformer);// Aplica as transformações de página
        if (items.size() > 1){
            binding.viewPager2.setCurrentItem(1);// Define a página atual
        } else if (!items.isEmpty()) {
            binding.viewPager2.setCurrentItem(0);// Define a página atual
        }

        binding.viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                sliderHandler.removeCallbacks(sliderRunnable); // Remove o Runnable quando a página for selecionada

            }
        });
    }
    // Remove o Runnable quando a atividade entra em pausa
    @Override
    protected void onPause() {
        super.onPause();
        sliderHandler.removeCallbacks(sliderRunnable);
    }
    // Recoloca o Runnable quando a atividade é retomada
    @Override
    protected void onResume() {
        super.onResume();
        sliderHandler.postDelayed(sliderRunnable,2000);// Troca de banners a cada 2 segundos
    }
}