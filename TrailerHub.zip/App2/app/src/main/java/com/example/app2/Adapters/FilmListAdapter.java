package com.example.app2.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.app2.Activities.DetailActivity;
import com.example.app2.Domains.Film;
import com.example.app2.R;

import java.util.ArrayList;

public class FilmListAdapter extends RecyclerView.Adapter<FilmListAdapter.Viewholder> {
    ArrayList<Film> items; //Lista de objetos do tipo Film que será exibida no RecyclerView
    Context context;     // Contexto da Activity, necessário para várias operações como inflar layouts e iniciar novas atividades

    // Construtor da classe, recebe a lista de filmes
    public FilmListAdapter(ArrayList<Film> items) {
        this.items = items;

    }
    // Método chamado para criar novas visualizações (ViewHolders) para o RecyclerView
    @NonNull
    @Override
    public FilmListAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext(); // Obtém o contexto da View
        // Infla o layout "film_viewholder" e cria uma nova instância de Viewholder
        View inflate  = LayoutInflater.from(parent.getContext()).inflate(R.layout.film_viewholder, parent, false);
        return new Viewholder(inflate);
    }

    // Método que vincula os dados aos componentes visuais (ViewHolder) com base na posição do item
    @Override
    public void onBindViewHolder(@NonNull FilmListAdapter.Viewholder holder, int position) {
        // Define o título do filme no TextView
        holder.titleTxt.setText(items.get(position).getTitle());

        // Configurações para carregar a imagem, aplicando o efeito de corte central (CenterCrop) e cantos arredondados (RoundedCorners)
        RequestOptions requestOptions = new RequestOptions();
        requestOptions=requestOptions.transform(new CenterCrop(), new RoundedCorners(30));
        // Usa a biblioteca Glide para carregar a imagem do pôster do filme
        Glide.with((context))
                .load(items.get(position).getPoster())// Carrega a URL da imagem do filme
                .apply(requestOptions) // Aplica as transformações (CenterCrop e RoundedCorners)
                .into(holder.pic);// Insere a imagem carregada no ImageView (pic)
        // Define um listener para quando o item for clicado
        holder.itemView.setOnClickListener(view -> {
            // Exibe a mensagem de que esta abrindo os detalhes
            Toast.makeText(context, "Abrindo detalhes de "+items.get(position).getTitle(), Toast.LENGTH_SHORT).show();
            // Cria uma intenção para abrir a DetailActivity e envia o objeto "Film" correspondente
            Intent intent=new Intent(context, DetailActivity.class);
            intent.putExtra("object", items.get(position));  // Passa o objeto Film para a próxima atividade
            context.startActivity(intent);// Inicia a nova atividade
        });
    }
    // Retorna o número total de itens na lista
    @Override
    public int getItemCount() {
        return items.size();
    }// Tamanho da lista de filmes

    // Classe interna que representa cada item individual no RecyclerView
    public class Viewholder extends RecyclerView.ViewHolder {
        TextView titleTxt;  // Componente para exibir o título do filme
        ImageView pic;  // Componente para exibir o pôster do filme

        // Construtor da Viewholder, inicializa os componentes da visualização
        public Viewholder(@NonNull View itemView) {
            super(itemView);
            titleTxt = itemView.findViewById(R.id.nameTxt);// Conecta o TextView da view ao objeto Java
            pic=itemView.findViewById(R.id.pic);    // Conecta o ImageView da view ao objeto Java
        }
    }
}
