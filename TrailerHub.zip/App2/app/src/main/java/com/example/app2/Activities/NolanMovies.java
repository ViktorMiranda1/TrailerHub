package com.example.app2.Activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.app2.Adapters.FilmListAdapter;
import com.example.app2.Domains.Film;
import com.example.app2.R;
import com.example.app2.databinding.ActivityNolanMoviesBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class NolanMovies extends AppCompatActivity {
    ActivityNolanMoviesBinding binding;
    private FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNolanMoviesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        database = FirebaseDatabase.getInstance();
        initNolanMovies();

        binding.backImgNolan.setOnClickListener(view -> finish());
    }

    private void initNolanMovies() {
        DatabaseReference myRef = database.getReference("Nolan Movies");
        binding.progressBarNolan.setVisibility(View.VISIBLE);
        ArrayList<Film> nolan = new ArrayList<>();
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    for (DataSnapshot issue: snapshot.getChildren()){
                        nolan.add(issue.getValue(Film.class));
                    }

                    if (!nolan.isEmpty()){
                        binding.recyclerViewNolan.setLayoutManager(new LinearLayoutManager(NolanMovies.this));
                        binding.recyclerViewNolan.setAdapter(new FilmListAdapter(nolan));
                    }
                    binding.progressBarNolan.setVisibility(View.GONE);

                } else {
                    Log.d("Nolan Movies", "No data found");
                }
                binding.progressBarNolan.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Nolan Movies", "Error fetching data", error.toException());
                binding.progressBarNolan.setVisibility(View.GONE);
            }
        });
    }
}