package com.example.app2.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.example.app2.databinding.ActivityIntroBinding;

public class IntroActivity extends AppCompatActivity {
    ActivityIntroBinding binding;// Utiliza View Binding para acessar os elementos da interface
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding =ActivityIntroBinding.inflate(getLayoutInflater()); // Inicializa o View Binding
        setContentView(binding.getRoot());// Define o layout principal da atividade com base no View Binding
        binding.startBtn.setOnClickListener(v -> startActivity(new Intent(IntroActivity.this, MainActivity.class))); // Define um listener para o botão "startBtn"
        // Quando o botão é clicado, uma nova Intent é criada para iniciar a `MainActivity`
        // Define a janela como "no limits" para criar um efeito de tela cheia, sem limites para status bar ou navigation bar
        Window w=getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
    }
}