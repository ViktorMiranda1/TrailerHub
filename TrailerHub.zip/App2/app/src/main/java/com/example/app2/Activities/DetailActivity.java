package com.example.app2.Activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.GranularRoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.app2.Domains.Film;
import com.example.app2.R;
import com.example.app2.databinding.ActivityDetailBinding;

import eightbitlab.com.blurview.RenderScriptBlur;

public class DetailActivity extends AppCompatActivity {
    private ActivityDetailBinding binding; // Usado para vincular os componentes da interface (View Binding)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Infla o layout usando View Binding
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot()); // Define a View principal

        setVariable(); // Chama o método para configurar os elementos da interface

        // Remove os limites da janela para dar a sensação de "tela cheia"
        Window w=getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

    }
    // Método que configura os dados e a interface
    private void setVariable() {
        // Recebe o objeto Film que foi passado pela FilmListAdapter
        Film item = (Film) getIntent().getSerializableExtra("object");

        // Configurações de opções para o Glide (para o pôster do filme)
        RequestOptions requestOptions=new RequestOptions();
        requestOptions=requestOptions.transform(new CenterCrop(),new GranularRoundedCorners(0,0,50,50));// Aplica cantos arredondados específicos

        // Usa o Glide para carregar a imagem do pôster do filme no ImageView
        Glide.with(this)
                .load(item.getPoster())// Carrega a URL do pôster do filme
                .apply(requestOptions)// Aplica as transformações no pôster
                .into(binding.FilmPic);// Define a imagem no ImageView correspondente
        if (item != null){ // Verifica se nao esta vazio a lista de itens
            binding.titleTxt.setText(item.getTitle()); // Define o título do filme no TextView
            binding.imdbTxt.setText("IMDB " +item.getImdb());// Define o texto da avaliação IMDB
            binding.movieTimesTxt.setText(item.getYear() + " - " + item.getTime()); // Define o texto com o ano e a duração do filme
            binding.movieSummery.setText(item.getDescription());// Define a sinopse do filme

        }else { //Caso haja algum problema ele avisa que deu erro
            Toast.makeText(this, "Erro ao carregar detalhes do filme", Toast.LENGTH_SHORT).show();
        }

        // Configura o botão para assistir ao trailer do filme
        binding.watchTrailerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Extrai o ID do trailer do YouTube
                String id = item.getTrailer().replace("https://www.youtube.com/watch?v=", "");
                // Cria uma Intent para abrir o app do YouTube
                Intent appIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+id));
                // Cria uma Intent para abrir o trailer no navegador se o app do YouTube não estiver disponível
                Intent webIntent=new Intent(Intent.ACTION_VIEW, Uri.parse(item.getTrailer()));
                // Um t[opico pedido
                try{
                    startActivity(appIntent);// Tenta abrir o trailer no app do YouTube
                }catch (ActivityNotFoundException ex){
                    startActivity(webIntent);// Se falhar, abre no navegador
                }
            }
        });
        // Configura o botão de "voltar"
        binding.backImg.setOnClickListener(view -> finish());// Finaliza a Activity e volta para a anterior
        // Configura a visualização embaçada (BlurView) para dar um efeito de fundo desfocado
        float radius=10f; // Define o raio do desfoque
        View decorView=getWindow().getDecorView(); // Obtém a View de decoração da janela
        ViewGroup rootView=(ViewGroup) decorView.findViewById(android.R.id.content);// Obtém o conteúdo da janela
        Drawable windowsBackground=decorView.getBackground();// Obtém o fundo da janela

        // Configura o efeito de desfoque na BlurView usando a biblioteca RenderScriptBlur
        binding.blurView.setupWith(rootView, new RenderScriptBlur(this))
                .setFrameClearDrawable(windowsBackground) // Define o fundo da janela como fundo da BlurView
                .setBlurRadius(radius);// Aplica o raio de desfoque
        binding.blurView.setOutlineProvider(ViewOutlineProvider.BACKGROUND);// Define a borda da BlurView
        binding.blurView.setClipToOutline(true);// Habilita o recorte da borda
    }
}